------------------------------------------
-- Author: Andrei "Garoth" Thorp        --
-- Copyright 2009 Andrei "Garoth" Thorp --
------------------------------------------

require("obvious.lib.hooks")
require("obvious.lib.markup")
require("obvious.lib.mpd")
require("obvious.lib.widget")
require("obvious.lib.wlan")

module("obvious.lib")
-- vim: filetype=lua:expandtab:shiftwidth=4:tabstop=4:softtabstop=4:encoding=utf-8:textwidth=80
